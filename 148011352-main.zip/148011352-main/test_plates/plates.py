# plates.py

def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")

def is_valid(s):
    # Check if length is between 2 and 6 characters
    if not (2 <= len(s) <= 6):
        return False

    # Ensure the first two characters are letters
    if not s[:2].isalpha():
        return False

    # Ensure the entire plate is alphanumeric
    if not s.isalnum():
        return False

    digit_started = False
    for i, char in enumerate(s):
        if char.isdigit():
            # Check for leading zero in the first number segment
            if char == '0' and not digit_started:
                return False
            digit_started = True
        elif digit_started:
            # No letters should follow after the first digit
            return False

    return True

if __name__ == "__main__":
    main()
