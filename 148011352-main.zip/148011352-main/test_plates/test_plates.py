# test_plates.py
import pytest
from plates import is_valid

def test_length():
    assert is_valid('AA') == True  # Minimum valid length
    assert is_valid('AAAAAA') == True  # Maximum valid length
    assert is_valid('A') == False  # Too short
    assert is_valid('AAAAAAA') == False  # Too long

def test_start_with_two_letters():
    assert is_valid('AA123') == True
    assert is_valid('A123') == False  # Not enough starting letters
    assert is_valid('1AA23') == False  # Starts with a number

def test_numbers_placement():
    assert is_valid('CS50') == True  # Valid placement of numbers
    assert is_valid('CS05') == False  # Invalid due to leading zero in numbers
    assert is_valid('AAA222') == True
    assert is_valid('AAA22A') == False  # Letters after numbers

def test_alphanumeric():
    assert is_valid('PI314') == True  # Valid alphanumeric
    assert is_valid('PI3.14') == False  # Contains punctuation
    assert is_valid('PIE!14') == False  # Contains special character
    assert is_valid('PI 14') == False  # Contains a space
