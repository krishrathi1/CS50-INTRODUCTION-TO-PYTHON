import re
import sys

def main():
    print(convert(input("Hours: ")))

def convert(s):
    # Define the regular expression to match the input time formats
    pattern = r"^(\d{1,2})(?::(\d{2}))? (AM|PM) to (\d{1,2})(?::(\d{2}))? (AM|PM)$"

    # Search for the pattern in the input string
    match = re.search(pattern, s)
    if not match:
        raise ValueError("Invalid format")

    # Extract hours, minutes, and AM/PM parts
    start_hour, start_minute, start_period, end_hour, end_minute, end_period = match.groups()

    # Convert hours and minutes to integers and handle missing minutes
    start_hour = int(start_hour)
    start_minute = int(start_minute) if start_minute else 0
    end_hour = int(end_hour)
    end_minute = int(end_minute) if end_minute else 0

    # Validate hour and minute ranges
    if not (1 <= start_hour <= 12 and 0 <= start_minute <= 59):
        raise ValueError("Invalid start time")
    if not (1 <= end_hour <= 12 and 0 <= end_minute <= 59):
        raise ValueError("Invalid end time")

    # Convert start time to 24-hour format
    start_hour_24 = convert_to_24_hour(start_hour, start_minute, start_period)
    end_hour_24 = convert_to_24_hour(end_hour, end_minute, end_period)

    return f"{start_hour_24:02}:{start_minute:02} to {end_hour_24:02}:{end_minute:02}"

def convert_to_24_hour(hour, minute, period):
    if period == "PM" and hour != 12:
        hour += 12
    elif period == "AM" and hour == 12:
        hour = 0
    return hour

if __name__ == "__main__":
    main()
