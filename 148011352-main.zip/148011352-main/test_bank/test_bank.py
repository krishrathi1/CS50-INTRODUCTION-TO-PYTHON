from bank import value

def main():
    test_hello()
    test_h()
    test_other()

    print("All tests passed!")  # Optional: Confirmation message

def test_hello():
    assert value("hello") == 0
    assert value("Hello") == 0
    assert value("HELLO") == 0

def test_h():
    assert value("hi") == 20
    assert value("Howdy") == 20
    assert value("H") == 20
    assert value("h") == 20

def test_other():
    assert value("Goodbye") == 100
    assert value("greeting") == 100
    assert value("welcome") == 100
    assert value("Bye") == 100

if __name__ == "__main__":
    main()
