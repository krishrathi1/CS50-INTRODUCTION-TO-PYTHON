import re
import sys

def main():
    print(validate(input("IPv4 Address: ")))

def validate(ip):
    # Regular expression for an IPv4 address with each number between 0 and 255
    pattern = r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$"
    match = re.search(pattern, ip)
    if match:
        # Check if all groups are in the range 0-255
        return all(0 <= int(num) <= 255 for num in match.groups())
    return False

if __name__ == "__main__":
    main()
