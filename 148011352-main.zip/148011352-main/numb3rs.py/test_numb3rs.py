from numb3rs import validate

def test_valid_ip():
    assert validate("192.168.1.1") == True
    assert validate("255.255.255.255") == True
    assert validate("0.0.0.0") == True

def test_invalid_ip():
    assert validate("275.3.6.28") == False  # Out of range
    assert validate("192.168.1") == False  # Missing one section
    assert validate("192.168.1.1.1") == False  # Too many sections
    assert validate("192.168.1.-1") == False  # Negative number
    assert validate("192.168.1.256") == False  # Out of range
    assert validate("192.168.1.abc") == False  # Non-numeric value

def test_boundary_cases():
    assert validate("255.0.255.0") == True  # Boundary numbers
    assert validate("256.100.100.100") == False  # Out of range at the start
    assert validate("100.100.100.256") == False  # Out of range at the end
