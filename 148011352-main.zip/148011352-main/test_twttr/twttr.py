def main():
    # Get user input
    word = input("Input: ")
    # Remove all vowels and print the output
    print("Output: " + shorten(word))


def shorten(word):
    # Loop through every letter
    new_word = ""
    # Check if it is not a vowel (whether inputted in uppercase or lowercase)
    for letter in word:
        if letter.lower() not in ['a', 'e', 'i', 'o', 'u']:
            # Add the letter to new_word if it's not a vowel
            new_word += letter
    return new_word


if __name__ == "__main__":
    main()
