import re
import sys

def main():
    print(parse(input("HTML: ")))

def parse(s):
    # Regular expression pattern for YouTube embed URLs
    pattern = r'src="(?:https?://)?(?:www\.)?youtube\.com/embed/([a-zA-Z0-9_-]+)"'

    # Search for the pattern in the input string
    match = re.search(pattern, s)
    if match:
        video_id = match.group(1)  # Extract the video ID
        return f"https://youtu.be/{video_id}"
    return None

if __name__ == "__main__":
    main()
