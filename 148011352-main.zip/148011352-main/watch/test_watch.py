from watch import parse

def test_parse_valid_urls():
    assert parse('<iframe src="https://www.youtube.com/embed/xvFZjo5PgG0"></iframe>') == "https://youtu.be/xvFZjo5PgG0"
    assert parse('<iframe src="http://youtube.com/embed/xvFZjo5PgG0"></iframe>') == "https://youtu.be/xvFZjo5PgG0"
    assert parse('<iframe src="https://youtube.com/embed/xvFZjo5PgG0"></iframe>') == "https://youtu.be/xvFZjo5PgG0"

def test_parse_invalid_urls():
    assert parse('<iframe src="https://www.vimeo.com/embed/xvFZjo5PgG0"></iframe>') == None
    assert parse('<iframe src="https://youtube.com/other/xvFZjo5PgG0"></iframe>') == None
    assert parse('<iframe width="560" height="315"></iframe>') == None

def test_parse_mixed_case():
    assert parse('<iframe src="https://www.YOUTUBE.com/embed/xvFZjo5PgG0"></iframe>') == "https://youtu.be/xvFZjo5PgG0"

def test_parse_with_additional_attributes():
    assert parse('<iframe width="560" height="315" src="https://www.youtube.com/embed/xvFZjo5PgG0" title="YouTube video player"></iframe>') == "https://youtu.be/xvFZjo5PgG0"
