# test_fuel.py
import pytest
from fuel import convert, gauge

# Tests for convert function
def test_convert_valid_input():
    assert convert("1/2") == 50
    assert convert("3/4") == 75
    assert convert("1/4") == 25

def test_convert_invalid_input():
    with pytest.raises(ValueError):
        convert("cat/dog")  # Non-integer inputs
    with pytest.raises(ValueError):
        convert("3/2")  # X is greater than Y
    with pytest.raises(ZeroDivisionError):
        convert("1/0")  # Division by zero

def test_convert_zero_and_full():
    assert convert("0/1") == 0  # Edge case of zero
    assert convert("4/4") == 100  # Edge case of full

# Tests for gauge function
def test_gauge_empty():
    assert gauge(0) == "E"  # Completely empty
    assert gauge(1) == "E"  # Almost empty

def test_gauge_full():
    assert gauge(99) == "F"  # Almost full
    assert gauge(100) == "F"  # Completely full

def test_gauge_middle():
    assert gauge(50) == "50%"  # Mid-level
    assert gauge(25) == "25%"  # Lower middle
    assert gauge(75) == "75%"  # Upper middle
