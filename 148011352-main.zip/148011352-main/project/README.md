# Hangman Game
#### Video Demo: [https://youtu.be/Gnkn47nhn3g?si=5ZCScViAyMrXT2m-](https://youtu.be/Gnkn47nhn3g?si=5ZCScViAyMrXT2m-)
#### Description:
The **Hangman Game** is a terminal-based Python program where players guess the name of a movie, letter by letter. The movie is selected randomly from a predefined list based on IMDb’s top 100 movies as of August 2022. With each guess, the player tries to reveal the hidden movie title within a limited number of attempts. The game provides hints after a few unsuccessful guesses by revealing the movie's release year. Players can also guess the full title if they feel confident!

### Project Structure
This project includes:
- **Main function (`main`)**: Initializes the game, selects a movie, and manages the game flow.
- **`select_movie`**: Randomly picks a movie title and its release year from the list.
- **`question`**: Creates a blanked-out version of the movie title for guessing, preserving spaces and punctuation.
- **`game`**: Runs the main game loop, taking player input and providing feedback based on correct or incorrect guesses.
- **`get_result`**: Displays the outcome based on whether the player successfully guessed the movie or ran out of attempts.

### Project Requirements:
- **Python Implementation**: The entire project is written in Python.
- **Functions**: The project includes a main function and three additional functions, each with corresponding unit tests.
- **Files**:
  - `project.py`: Contains the main code for running the Hangman game.
  - `test_project.py`: Includes test functions (`test_select_movie`, `test_question`, and `test_get_result`) to ensure functionality using pytest.
- **Library Requirements**: Any external libraries needed for the project should be listed in `requirements.txt`. This can be empty if no additional libraries are required.

### Game Instructions:
1. Clone the project:
   ```bash
   git clone <your_repository_url>
