from um import count
import pytest

def test_single_um():
    assert count("um") == 1
    assert count("Um") == 1
    assert count("hello, um, world") == 1

def test_multiple_um():
    assert count("um um um") == 3
    assert count("Um, hello um, um.") == 3
    assert count("UM, how many times did I say um?") == 2

def test_um_not_word():
    assert count("yummy") == 0
    assert count("umbrella") == 0
    assert count("album") == 0

def test_um_mixed_cases():
    assert count("UM um Um") == 3
    assert count("UM...Um...um.") == 3

def test_no_um():
    assert count("hello world") == 0
    assert count("") == 0
    assert count("Here is some text without the word") == 0
