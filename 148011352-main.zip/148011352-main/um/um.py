import re
import sys

def main():
    print(count(input("Text: ")))

def count(s):
    # Define the regex pattern for the word "um" as a standalone word, case-insensitive
    pattern = r"\bum\b"
    # Use re.findall to get a list of all matches and return the length
    matches = re.findall(pattern, s, re.IGNORECASE)
    return len(matches)

if __name__ == "__main__":
    main()
