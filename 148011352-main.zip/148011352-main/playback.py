# playback.py

# Prompt the user for input
user_input = input("Enter some text: ")

# Replace each space with "..."
modified_input = user_input.replace(" ", "...")

# Output the modified input
print(modified_input)
