# indoor.py

# Get input from the user
user_input = input("")

# Convert the input to lowercase
lowercase_input = user_input.lower()

# Print the lowercase input
print(lowercase_input)
